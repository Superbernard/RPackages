#' Read data file from directory
#' 
#' This function takes the name and directory of the data file and import it into r.
#' 
#' @param file The name of the data file to be read.
#' @param address The file path.
#' @return The data set read with header.
#' @author Zhicong Chu
#' @export 



my.read=function(file,address){
  adtfile=paste(address,file,sep="") # adtfile is the address to file
  data=read.table(adtfile,sep=",",header=TRUE)
  data
}