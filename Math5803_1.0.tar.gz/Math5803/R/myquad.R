#' Bayesian quadratic regression
#' 
#' This function runs the Bayesian model of polynomial regression with a quadratic term (x^2).
#' 
#'@param x Vector that contains x (predictor) values for the data.
#'@param y Vector that contains y (response) values  for the data.
#'@param alpha Setting the range for HDI for plotting. (1-alpha) BCI. 
#'@param nit Number of iterations in each chain.
#'
#'@return  \describe{A list that contains summary statistcs from both classical and Bayesian models.
#'   \item{result_class}{The summary statistcs from classical model.}
#'   \item{result_bays}{The summary statistcs from Bayesian model.}
#' 
#' }
#'
#'@details Histgrames of posterior of all parameters estimated will also be generated 
#'on the same plot with (1-alpha) BCI marked. 
#'
#'
#'
#'@author Zhicong Chu
#'@export  
#'@seealso \code{plotBCI}
#'@import BRugs 
#'@examples
#'n=40
#'x=1:n
#'set.seed(30);y=400+ 3*x - 1/4*x^2 + rnorm(n,0,10)
#'plot(x,y)
#'myquad(x=x,y=y,alpha=0.80,nit=10000)



myquad<-function(x,y,alpha,nit){
  
  #library(BRugs)
  # Specify the model in BUGS language, but save it as a string in R:
  modelstring="
  model{
  for(i in 1:N){ # loading the lik
  y[i]~dnorm(mu[i],tau)# y normally dist
  mu[i]<-beta0+beta1*x[i]+beta2*x_sq[i]  # Linear regression
  x_sq[i]<-pow(x[i],2)
  }
  beta0~dnorm(0,tau0) # prior on intercept
  beta1~dnorm(0,tau1) 
  beta2~dnorm(0,tau2)
  
  sigma~dunif(0,100) # 1/sigma^2  prior on tau
  tau<-pow(sigma,-2)
  
  }
  "
  
  # Write the model to a file
  writeLines(modelstring,con="model.txt")
  dir()
  
  #Check model
  modelCheck("model.txt")
  
  
  # Make data
  datalist=
    list(y=y
         ,
         x=x,
         N=n,
         tau0=0.00001,
         tau1=0.00001,
         tau2=0.00001
    )
  
  modelData(bugsData(datalist))
  modelCompile(numChains=3)
  
  
  writeLines("list(beta0=0,beta1=0.01,beta2=0.01,sigma=1)",con="inits.txt")  #write a file containing the inits
  modelInits(rep("inits.txt", 3))  # read init data file
  modelGenInits()      # Generate inits for anything left
  
  modelUpdate(1000)                    # burn in
  samplesSet(c("beta0","beta1","beta2","sigma"))     # all parameters should be monitored
  modelUpdate(nit)                    # nit more iterations ....
  result_bays<-samplesStats("*")
  
  
  post_beta0=samplesSample("beta0")       # Collect the MCMC posterior sample
  post_beta1=samplesSample("beta1")
  post_beta2=samplesSample("beta2")
  post_sigma=samplesSample("sigma")
  
  windows()
  layout(matrix(1:4,2,2,byrow=T))
  b0<-plotBCI(post_beta0,alpha,"beta0")
  b1<-plotBCI(post_beta1,alpha,"beta1")
  b2<-plotBCI(post_beta2,alpha,"beta2")
  sig<-plotBCI(post_sigma,alpha,"sigma")
  
  x_sq<-x^2
  reg.lm=lm(y~x+x_sq)
  result_class<-summary(reg.lm)
  
  
  return(list(result_class,result_bays))
  
}


