#' Marginal normality
#' 
#' This function takes the sample matrix X and check the marginal normality for each variable in X.
#' 
#' @param X A numeric matrix that contains the values of X in the sample.
#' @return The Q-Q plot for each variable of X in a pop-out window.
#' @author Zhicong Chu
#' @seealso \code{myqq}
#' @export   
#' @examples 
#' library(MASS)
#' Sig=matrix(c(2,1,1,3),nr=2,nc=2,byrow=TRUE)
#' mu=rep(0,2)
#' X<-mvrnorm(20,mu,Sig=Sig)
#' mymultiqq(X)

mymultiqq=function(X) {
  
  for(i in 1:ncol(X)) {
    t1=substitute(X[i], list(i=i))
    windows()
    myqq(X[,i], main=bquote(paste("Normal Q-Q Plot for ",.(t1))))
    qqline(X[,i])}
}

