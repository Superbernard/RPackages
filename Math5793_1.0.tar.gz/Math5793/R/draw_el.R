#' Draw an ellipse from given data points
#' 
#' Takes in a mtrix containing coordinate values plot the datapoints 
#' and add a default ellipse on it. 
#' 
#'@param mat A numeric n by 2 matrix that contains "x" and "y" 
#'values in columns.
#'@return A scatter plot with data points of given "x" and "y" values as well as a default ellipse on it. 
#'
#'@details 
#'The default ellipse outlines a 95% confidene region of the matrix.
#'@seealso \code{ellipse}
#'
#'
#'@author Zhicong Chu
#'@export  
#'@importFrom ellipse ellipse
#'
#'@examples
#'s11=100
#'s22=400
#'s12=100
#'s21=s12
#'library(mvtnorm)
#'sig=matrix(c(s11,s21,s12,s22),nrow=2,ncol=2)
#'set.seed(120)
#'mat=rmvnorm(100,mean=c(0,0),sigma=sig)
#'x1=mat[,1]
#'x2=mat[,2]
#'windows()
#'plot(x2~x1, main='MV Normal Points' , xlim=c(-35,35),ylim=c(-65,65),las=T)
#'mat
#'draw_el(mat)





draw_el=function(mat){
  n=dim(mat)[1]
  covx=n/(n-1)*cov(mat)
  pts=ellipse(covx)
  x1=mat[,1]
  x2=mat[,2]
  ran_x1=max(x1)-min(x1)
  ran_x2=max(x2)-min(x2)
  windows()
  plot(x2~x1, main='Normal Points',xlim=c(0-0.7*ran_x1,0.7*ran_x1),
       ylim=c(0-0.7*ran_x2,0.7*ran_x2), las=T)
  points(pts,type="l",col='blue',lwd=2)
  abline(v=0,h=0)
}