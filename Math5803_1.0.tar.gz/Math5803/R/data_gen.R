#' Simulated data generation for hierarchical model.
#' 
#' This function that creates dataset by specifying hyper-parameter w and k.
#' 
#' @param w First hyper-parameter of theta.Default is 0.45.
#' @param k Second hyper-parameter of theta.Default is 20.

#' @author Zhicong Chu
#' @details The math expression for y is theta~beta(w*(k-2)+1,(1-w)*(k-2)+1)),
#' y~binomial(theta)
#' @return The generated dataset. The dataset is a list with y and s in it. 
#' y is the binomial response and s is the number of subjects.
#' @export
#' @examples 
#' dummydata<-data_gen(k=k)


data_gen<-function(w=0.45,k=20){  #function to create dataset by specifying w and k
  
  set.seed(32);theta=round(rbeta(20,w*(k-2)+1,(1-w)*(k-2)+1),4)
  theta
  y=rbinom(100,1,rep(theta,rep(5,20)))
  length(y)
  barplot(table(y))
  
  #100 ys, 20 different coins from the same mint Nsubj=20
  s=rep(1:20,rep(5,20))
  s
  data=list(s=s,y=y)
  data=data.frame(y=y,s=s)
  
  return(data)
}