#' Bivariate normal distribution density.
#' 
#' This functions provide contour and perspective plots of prio,
#' likelihood and posterior of 2-parameter Bayesian analysi.
#' 
#' @param n1 Number of trials in regard with theta1.
#' @param n2 Number of trials in regard with theta2.
#' @param x1 Number of success in regard with theta1.
#' @param x2 Number of success in regard with theta2.
#' @param a1 First hyper-parameter of theta1 assuming beta destribution on thetas.
#' @param b1 Second hyper-parameter of theta1 assuming beta destribution on thetas. 
#' @param a2 First hyper-parameter of theta2 assuming beta destribution on thetas.
#' @param b2 Second hyper-parameter of theta2 assuming beta destribution on thetas.
#' @param nd Number of discrete values of theta.
#' @return Two plots showing contour and perspective plots of prior, likelihood and posterior.
#' @details This function returns 2 plots with all the contours of prior , likelihood and posterior 
#' on one plot and all the persps of prior , likelihood and posterior on the other plot.
#' @author Zhicong Chu
#' @export
#' @examples 
#' ans<-my2param(10,10,4,5,1,1,2,2,20)
#' ans
#' 
#' 



my2param<-function(n1,n2,x1,x2,a1,b1,a2,b2,nd){
  
  theta1<-seq(0,1,length=nd)
  theta2<-theta1
  
  prior=function(theta1,theta2,a1,b1,a2,b2) {
    tmp=dbeta(theta1,a1,b1)*dbeta(theta2,a2,b2)
    tmp/sum(tmp)
  }
  
  lik=function(theta1,theta2) dbinom(x=x1,prob=theta1,size=n1)*dbinom(x=x2,prob=theta2,size=n2)
  
  post=function(theta1,theta2,alpha1,beta1,alpha2,beta2,x1,n1,x2,n2) {
    tmp=dbeta(theta1,shape1=alpha1+x1,shape2=beta1+n1-x1)*dbeta( theta2,shape1=alpha2+x2,shape2=beta2+n2-x2)
    tmp/sum(tmp)
  }
  
  
  #pr<-prior(theta1,theta2,a1,b1,a2,b2)
  #liki<-lik(theta1,theta2)
  #posti<-post(theta1,theta2,a1,b1,a2,b2,x1,n1,x2,n2)
  
  out.pr<-outer(theta1,theta2,prior,a1,b1,a2,b2)
  out.liki<-outer(theta1,theta2,lik)
  out.posti<-outer(theta1,theta2,post,a1,b1,a2,b2,x1,n1,x2,n2)
  
  graphics.off()
  windows()
  layout(matrix(c(1,2,3,3),nr=2,nc=2,byrow=TRUE))
  contour(out.pr,xlab="theta1",ylab="theta2",main="prior")
  contour(out.liki,xlab="theta1",ylab="theta2",main="likilihood")
  contour(out.posti,xlab="theta1",ylab="theta2",main="postierior")
  
  windows()
  layout(matrix(c(1,2,3,3),nr=2,nc=2,byrow=TRUE))
  par(bg = "white")
  z <- out.pr # grid approximation (nice)
  nrz <- nrow(z)
  ncz <- ncol(z)
  # Create a function interpolating colors in the range of specified colors
  jet.colors <- colorRampPalette( c("blue", "green") )
  # Generate the desired number of colors from this palette
  nbcol <- 100
  color <- jet.colors(nbcol)
  # Compute the z-value at the facet centres
  # z is a matrix, z[-1,-1] romoves the first row and first column
  zfacet <- z[-1, -1] + z[-1, -ncz] + z[-nrz, -1] + z[-nrz, -ncz]
  # Recode facet z-values into color indices
  facetcol <- cut(zfacet, nbcol)
  persp(theta1, theta2, z, col = color[facetcol], phi = 30,
        theta = -30,zlab="probability",main= "prior")
  
  z <- out.liki # grid approximation (nice)
  nrz <- nrow(z)
  ncz <- ncol(z)
  # Create a function interpolating colors in the range of specified colors
  jet.colors <- colorRampPalette( c("blue", "green") )
  # Generate the desired number of colors from this palette
  nbcol <- 100
  color <- jet.colors(nbcol)
  # Compute the z-value at the facet centres
  # z is a matrix, z[-1,-1] romoves the first row and first column
  zfacet <- z[-1, -1] + z[-1, -ncz] + z[-nrz, -1] + z[-nrz, -ncz]
  # Recode facet z-values into color indices
  facetcol <- cut(zfacet, nbcol)
  persp(theta1, theta2, z, col = color[facetcol], phi = 30,
        theta = -30,zlab="probability",main= "likilihood")
  
  z <- out.posti # grid approximation (nice)
  nrz <- nrow(z)
  ncz <- ncol(z)
  # Create a function interpolating colors in the range of specified colors
  jet.colors <- colorRampPalette( c("blue", "green") )
  # Generate the desired number of colors from this palette
  nbcol <- 100
  color <- jet.colors(nbcol)
  # Compute the z-value at the facet centres
  # z is a matrix, z[-1,-1] romoves the first row and first column
  zfacet <- z[-1, -1] + z[-1, -ncz] + z[-nrz, -1] + z[-nrz, -ncz]
  # Recode facet z-values into color indices
  facetcol <- cut(zfacet, nbcol)
  persp(theta1, theta2, z, col = color[facetcol], phi = 30,
        theta = -30,zlab="probability",main= "postierior")
  
} 



