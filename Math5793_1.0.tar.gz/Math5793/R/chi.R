#' Chi-square quantile
#' 
#' This function takes the upper tail probability alpha and degree of freedom df, and calculate the quantile.
#' 
#' @param alpha The upper tail probability value.
#' @param df Degree of freedm. Default value is 3.
#' @return Quntile.
#' @author Zhicong Chu
#' @export 
#' @seealso \code{qchisq}
#' @examples 
#' qchisq(1-0.05,3)  #Calculate the quntile from the lower tail probability.
#' c_sq(0.05,3)      #Calculate the quntile from the upper tail probability.
#' 
#' 
#' 
#' 

c_sq<-function(alpha,df=3){
  output=qchisq(1-alpha, df)
  return(output)
}