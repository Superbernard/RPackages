#' Calculate angle between 2 vectors.
#' 
#' This function take 2 numeric vectors and calculate the angle between them.
#' 
#'@param x  A numeric vector that contains coordinate values. 
#'@param y  Another numeric vector that contains coordinate values.
#'@return The angle between two input vectors in degree.
#'@author Zhicong Chu
#'@export
#'@examples
#'ang_d(c(1,0),c(0,1))


ang_d<-function(x,y){  #define a function to calculate angle between 2 vectors
  lx<-sqrt(sum(x*x))
  ly<-sqrt(sum(y*y))
  theta=acos(sum(x*y)/(lx*ly))*180/pi  #angle in degree
  return(theta)
}