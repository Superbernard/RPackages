#' Derivative function
#' 
#' This function takes the input variable t, the original function to be derivated and the delta "change in" term and outputs the derivative function.
#' 
#' @param t The input variable t.
#' @param orifun The original function to be derivated.
#' @param delta The "change in" term. Default value is 0.0001.
#' 
#' @return The derivated function.
#' 
#' @details The derivation is based on the theory that f'(x)=lim (f(x)+f(delta))/delta when delta is close to 0.
#' @export
#' @author Zhicong Chu
#' 




fdash=function(t,orifun,delta=0.0001){
  #function to calculate derivative from an original function 
  output=(orifun(t+delta)-orifun(t))/delta
  return(output)
}