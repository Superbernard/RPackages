#' Coin-die Bayes Box
#' 
#' Function that demonstrates A two state Bayes box useful for simulation with coin and die.
#' 
#'@param  k  The number of faces in the event set E for acceptance of proposal. Default is 1.
#'@param  Lik The likelihood for 2 states of theta.
#'@param  theta Two states.
#'@param  h1 Small or big relative to h2. "s" represents small and "b" represents big. Default is "s".
#'
#' @return  \describe{A list of items that contains Bayes box output matrix, latex output, h values and h1 and k from the input.
#' A plot will alos be generate with proposal distribution and porportion to target h plots in two seperate panels.
#'   \item{bbox}{Bayes box output.}
#'   \item{latex}{Latex output. }
#'   \item{h}{The vector that contains h1 and h2 values. h=prior*likelihood.}
#'   \item{h1}{Small or big relative to h2. }
#'   \item{k}{The number of faces in the event set E for acceptance of proposal. Default is 1. }
#' }
#'@author Zhicong Chu
#'@export
#'@import xtable
#'@examples
#'cdbbox(k=1,lik=dbinom(x=6,size=10,prob=c(0.5,0.8)),theta=c(0.5,0.8),h1="b")->ans
#'ans


cdbbox<-function(k=1,lik,theta, h1="s"){ # K=1...6
  # xtable is a library which has functions useful for latex output
  #library(xtable)
  # rename the first and second components of the likelihood
  lik1<-lik[1]
  lik2<-lik[2]
  # We will now make a prior that has the desired characteristics
  # See pdf for proof of following
  # if h1 small "s" then ... else ...
  ifelse(h1=="s",pi1<-k/6*lik2/(lik1+k/6*lik2), pi1<-lik2/(lik2+k/6*lik1))
  # sum of probs is 1
  prior=c(pi1,1-pi1)
  #lik<-c(lik1,lik2)
  h<-prior*lik
  # Bayes
  post=h/sum(h)
  # Make a matrix for the Bayes box
  mat<-cbind(theta,prior,lik,h,post)
  rownames(mat)<-1:length(lik)
  Totals=c(NA,sum(prior),NA,sum(h),sum(post))
  mat2=rbind(mat,Totals)
  
  # Now make some plots useful in explaining the procedure
  layout(matrix(c(1,2),nr=1,nc=2,byrow=TRUE))
  barplot(matrix(c(0.5,0.5),nc=2,nr=1,byrow=TRUE,dimnames=list(c("Coin"),theta)),ylim=c(0,1),las=1,main="Proposal\n Uniform")
  barplot(matrix(h,nc=2,nr=1,byrow=TRUE,dimnames=list(c("Coin"),theta)),ylim=c(0,max(h)+0.5*max(h)),las=1,main="Proportional to target\n h")
  # Return a list of useful objects
  return(list(bbox=mat2,latex=xtable(mat2,digits=6),h=h,h1=h1,k=k))
}




