#' Two normal distribution plot function
#' 
#' This function plot areas of two given bounds under curves of two normal distribution.  
#' 
#'@param mean1 A numeric value that specifies the mean of the first normal distribution.Default value is 5.
#'@param mean2 A numeric value that specifies the mean of the second normal distribution.Default value is 10.
#'@param sd1 A numeric value that specifies the standard deviation of the normal distribution.Default value is 5.
#'@param sd1 A numeric value that specifies the standard deviation of the normal distribution.Default value is 8.
#'@param l1 A numeric value that specifies the lower bound of the area of the first distributon. Default value is 2.
#'@param u1 A numeric value that specifies the lower bound of the area of the first distributon. Default value is 6.
#'@param l2 A numeric value that specifies the lower bound of the area of the second distributon. Default value is 8.
#'@param u2 A numeric value that specifies the lower bound of the area of the second distributon. Default value is 12.
#'
#'@return A plot with curves of the specified normal distributions. And the areas of the given bounds under the curves are shaded in different colors.
#'
#'@author Zhicong Chu
#'@export
#'
#'@examples
#'windows()
#'my.twonorm(l1=0,l2=-5)



my.twonorm=function(mean1=5,sd1=5,mean2=10,sd2=8,l1=2,u1=6,l2=8,u2=12)
{
  
  xlow1=mean1-3*sd1
  xup1=mean1+3*sd1
  xlow2=mean2-3*sd2
  xup2=mean2+3*sd2
  
  curve(dnorm(x,mean1,sd1),xlim=c(min(xlow1,xlow2),max(xup1,xup2)),ylab="Density",lwd=2)
  curve(dnorm(x,mean2,sd2),add=TRUE)
  
  xcurve1=seq(l1,u1,length=1000)
  ycurve1=dnorm(xcurve1,mean1,sd1)
  polygon(c(l1,xcurve1,u1),c(0,ycurve1,0),col=rgb(0.5,0,0,alpha=0.6))
  
  xcurve2=seq(l2,u2,length=1000)
  ycurve2=dnorm(xcurve2,mean2,sd2)
  polygon(c(l2,xcurve2,u2),c(0,ycurve2,0),col=rgb(0,0.5,0,alpha=0.3))
  
  area1=pnorm(u1,mean1,sd1)-pnorm(l1,mean1,sd1)
  area2=pnorm(u2,mean2,sd2)-pnorm(l2,mean2,sd2)
  
  area1=round(area1,4)
  area2=round(area2,4)
  
  title("Two normals")
  text((l1+u1)/2,0.5*max(dnorm(l1:u1,mean1,sd1)),paste("Area1=",area1))
  text((l2+u2)/2,0.3*max(dnorm(l2:u2,mean2,sd2)),paste("Area2=",area2))
}
