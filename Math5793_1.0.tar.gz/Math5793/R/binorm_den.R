#' Bivariate normal distribution density.
#' 
#' This functions provide the density function for the bivariate normal distribution.
#' @param x A numeric matrix of quantiles.
#' @param sigma A numeric matrix of covariance.
#' @param mu A numeric vector of mean. 
#' @return The density value.
#' 
#' @author Zhicong Chu
#' @export
#' @examples 
#' x1<-rnorm(20,3,4)
#' x2<-rnorm(20,1,7)
#' X<-cbind(x1,x2)
#' sigma<-cov(X)
#' mu<-c(mean(x1),mean(x2))
#' norm.den(c(mean(x1),mean(x2)),sigma,mu)
#' 
#' norm.den(c(1,1),sigma=sigma,mu=c(0,0))==dmvnorm(c(1,1),c(0,0),sigma)  #test the function
#' sigma1<-matrix(c(10,-5,-5,20),ncol=2)
#' mu1=c(0,0)
#' norm.den(c(-2,-2),sigma=sigma1,mu=c(0,0))
#' 
#' 



norm.den=function(x,sigma,mu) {
  a=1/(2*pi*(det(sigma))^(1/2))
  b=-(x-mu)%*%solve(sigma)%*%matrix((x-mu),nrow=2)/2
  density=a*exp(1)^b
  return(density)
}


