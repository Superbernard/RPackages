#' Maximum likelihood parameter, grid method.
#' 
#' This function uses the grid method to find the value of parameter for maximum likelihood.
#' 
#' @param lfun The probability density function of the distribution of x.
#' @param x A numeric vector that contains the values of the input variable of the sample.
#' @param param A numeric vector that contains a series of different values of the other parameter of the density function. The values will be substituted into the likelihood function to compare for a maximum likelihood.
#' @author Zhicong Chu
#' @details This function substitutes a series of different values of the parameters into the likelihood function and find the value at maximum likelihood via comparison. The curve of the likelihood function to the parameter value will also be displayed. 
#' @return The value of the parameter at maximum likelihood
#' @export
#' @examples 
#' logbin=function(x,param) log(dbinom(x,prob=param,size=10))  #binomial distribution, log form
#' mymaxlik(x=c(5,5,6,6,6,6),param=seq(0,1,length=1000),lfun=logbin)


mymaxlik=function(lfun,x,param){
  z=outer(x,param,lfun)
  y=apply(z,2,sum)
  plot(param,y,col="Blue",type="l",lwd=2)
  i=max(which(y>=max(y)))
  abline(v=param[i],lwd=2,col="Red")
  text(locator(1),paste("max lik.","=",round(param[i],2)))
  points(param[i],y[i],pch=19,cex=1.5,col="Black")
  return(param[i])
}