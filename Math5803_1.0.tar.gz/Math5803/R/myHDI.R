#' Get HDI of MCMC sample
#' 
#' This function takes posterior samples and parameter of BCI range as well as 
#' the parameter names and plot out (1-alpha) BCI for all Bayesian estimates.
#' 
#'@param post_dist Posterior samples from MCMC.
#'@param alpha Parameter that determines HDI range to display on plot. (1-alpha) HDI
#'@param Title The title for the plot.
#'
#'@return Histgrams of the parameter on with (1-alpha) HDI marked.
#'@author Zhicong Chu
#'@export
#'


myHDI<-function(post_dist,alpha, title){
  if (!requireNamespace("TeachingDemos", quietly = TRUE)) {
    stop("Pkg TeachingDemos needed for this function to work. Please install it.",
         call. = FALSE)
  }
  #libarary(TeachingDemos)
  stat.hist=hist(post_dist,plot=FALSE)
  br=stat.hist$breaks
  d=stat.hist$density
  h<-hist(post_dist,plot=FALSE,breaks=80,freq=F)
  
  po_mu<-mean(post_dist)
  
  
  HDI<-emp.hpd(post_dist,conf=alpha)
  cuts2 = cut(h$breaks, c(min(post_dist),HDI[1], HDI[2],max(post_dist)))
  plot(h, col=c(rgb(1,1,1,alpha=0.25),rgb(1,0,0,alpha=0.25),
                rgb(1,1,1,alpha=0.25))[cuts2],
       freq=FALSE,ylim=c(0,max(d)*1.1), main=title,xlab = "Size")
  
  abline(v=po_mu,lwd=2,col="red")
  text(po_mu,max(d),labels="point estimator (mean)")
}