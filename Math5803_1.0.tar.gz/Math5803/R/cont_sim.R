#' Continous simulations via MCMC from posterior with beta proposal
#' 
#' This function makes continous simulations with beta proposal from a posterior
#' 
#' @param n Number of iterations. Default is 1000.
#' @param init The initial state. Default is 1.
#' @param h The function that defines h.
#' @param a The first hyper-parameter of beta proposal.
#' @param b The second hyper-parameter of beta proposal.
#' 
#' @return  \describe{A list contains iteration table, posterior distribution 
#' from MCMC simulation and posterior distribution from analytical solution.
#'   \item{matrix}{Iteration matrix that contains values of prop,u,alpha and post of
#'    each iteration from MCMC simulation.}
#'   \item{summary}{Summary information of posterior states of all iterations.}
#'   
#' } 
#' 
#' @details A histgram will be also generated that displays the posterior distribution 
#' from MCMC.
#' @export
#' @author Zhicong Chu
#' @examples 
#' 
#'disease<-cont_sim(n=20000)
#'
#'quantile(disease$matrix[,"post"], probs = c(0.025, 0.975) ) # 95% BCI
#'
#'
#'sam_mean<- mean(disease$matrix[,"post"])  # sample mean 
#'sam_mean
#'
#'sam_sd<- sd(disease$matrix[,"post"]) # sample mean 
#'sam_sd
#'
#'sam_median<- median(disease$matrix[,"post"])  # sample median
#'sam_median



cont_sim<-function(n=100,init=0.5, h=function(theta){dunif(theta)*dbinom(x=4,size=10,prob=theta)},a=1,b=1){
  #dbeta(x, shape1, shape2, ncp = 0, log = FALSE)
  alpha<-c() # holds transition probs
  alpha[1]<-1
  u<-c() # holds uniform values
  u[1]<-1
  post<-c()# post sample
  prop<-c() # vec of proposed states 1s and 2s
  prop[1]=init # initial state
  post[1]=prop[1]
  q=function(x){dbeta(x,a,b)}
  for(i in 2:n){ # starts at 2 because initial value given above
    rbeta(1,a,b)->prop[i]
    
    alpha[i]=min(1,h(prop[i])*q(post[i-1])/(h(post[i-1])*q(prop[i])))
    u[i]=runif(1)
    ifelse(u[i]<=alpha[i],post[i]<-prop[i],post[i]<-post[i-1])
  }
  res<-matrix(c(prop,u,alpha,post ),nc=4,nr=n,byrow=FALSE,dimnames=list(1:n,c("prop","u","alpha","post")))
  windows()
  hist(post,freq=FALSE,col= "red", xlab= "theta", ylab="sample posterior",
       main= "Sample posterior from MCMC of Zhicong", xlim=c(0,1))
  
  return(list(matrix=res,summary=summary(post)) )
}

