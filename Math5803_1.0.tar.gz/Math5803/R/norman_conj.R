#' Normal Conjugate
#' 
#' This function takes data, and parameters of conjugate normal prior and likelihood as input and report posterior distribution.   
#' 
#' @param x A numeric vector containing x values from the data.
#' @param sigma The standard diviation of the likelihood. 
#' @param mu0 The mean of prior distribution.
#' @param sigma0 The standard diviation of prior distribution.
#' @param alpha The parameter that determins the shading area which is the center 
#' (1-alpha)*100\% of posterior. 
#' @return  \describe{A list of values that contains evidence, posterior mean and 
#' posterior variance. And a plot will also be generated to display prior and posterior distribution on the same plot, with the center (1-alpha)*100/% area of posterior shaded. 
#'   \item{evidence}{The evidence}
#'   \item{post_mean}{The posterior mean }
#'   \item{post_var}{The posterior variance.}
#' }
#'   
#' @author Zhicong Chu
#' @details The function assumes that the variance of the conjugate likelihood is known. 
#' @export
#' @examples 
#' norm_conj(x=rnorm(20,mean=10,sd=4),sigma=4,mu0=10,sigma0=1,alpha=0.05)
#'      


norm_conj=function(x,sigma,mu0,sigma0,alpha){
  
  # function inside function
  prior=function(mu) dnorm(x=mu,mean=mu0,sd=sigma0)
  
  # number of data
  n=length(x)
  
  #posterior results from conjugate table
  m=(mu0/sigma0^2+n*mean(x)/sigma^2)/(1/sigma0^2+n/sigma^2)
  
  s=sqrt((1/sigma0^2+n/sigma^2)^(-1))
  
  #posterior function
  post=function(mu){
    dnorm(x=mu,mean=m,sd=s)
  }
  
  #make some appropriate xlimits
  
  xint=c(mean(x)-3*sigma,mean(x)+3*sigma)
  xval=seq(xint[1],xint[2],length=1000)
  ymax=max(c(post(xval),prior(xval)))
  
  #xpr_up = qnorm( 1 - alpha, mean = mu0, sd = sigma0 ) # set up upper and lower limits for shading      
  #xpr_low = qnorm( alpha, mean = mu0, sd = sigma0 )
  #xprval = seq( xpr_low, xpr_up, length = 1000)  #1000 points between the shading limits
  
  
  xpo_up = qnorm( 1 - 1/2*alpha, mean = m, sd = s) # set up upper and lower limits for shading  
  xpo_low = qnorm( 1/2*alpha, mean = m, sd = s )  
  xpoval = seq( xpo_low, xpo_up, length = 1000)   #1000 points between the shading limits
  
  # Make some plots
  
  curve(post(x),xlim=xint,ylim=c(0,ymax),xlab = "mu", ylab =  "probability",
        main = "Normal conjugate plot of Zhicong")
  polygon(c(xpo_low, xpoval, xpo_up),c(0, post(xpoval),0),col=rgb(0,0.2,0.5,alpha=0.3))
  
  #polygon(c(xpr_low, xprval, xpr_up),c(0, prior(xprval),0),col=rgb(0.5,0.2,0.1,alpha = 0.5))
  curve(prior(x),add=TRUE, col = "red")
  
  legend("topleft",legend=c("Posterior", "Prior"),fill=c("black","red"))
  
  lik = dnorm(x , xval, 4) #likihood with known variance sigma=4
  pr = prior(xval)
  px = sum(lik * pr) #evidence equals sum of production of likihood and prior
  px = round(px, digits = 4) #4 decimal places
  
  po_mu = round(m, digits = 4)  #postierior mean according to the conjugate table
  po_var = round((s^2), digits = 4)  #postierior variance according to the conjugate table
  
  output = list(evidence = px, post_mean = po_mu, post_var = po_var)
  
  return(output)
  
}