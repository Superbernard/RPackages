#' Likelihood function
#' 
#' This function takes inoput variable x and the other parameter of the density funtion and outputs the likelihood function.
#' 
#' @param x A numeric vector that contains the values of the input variable of the sample.
#' @param param The other parameter to be specified of the density function.
#' @param pdfun The probability density function of the distribution of x.
#' 
#' @return The likihood function.
#' @author Zhicong Chu
#' @export
#' 
#'   



likeh=function(x,param,pdfun){
  #likelihood function to be maximized, a function of param 
  #when x and probability density function pdfun is assigned
  z=outer(x,param,pdfun)
  output=apply(z,2,sum)
  return(output)
}  