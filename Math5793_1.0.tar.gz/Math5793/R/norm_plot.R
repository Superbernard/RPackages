#' Univariate normal distribution plot function
#' 
#' This function displays the area of a given bound under the density curve of a normal distribution.
#' 
#'@param mean A numeric value that specifies the mean of the normal distribution.Default value is 10.
#'@param sd A numeric value that specifies the standard deviation of the normal distribution.Default value is 5.
#'@param l A numeric value that specifies the lower bound of the area. Default value is -2.
#'@param u A numeric value that specifies the lower bound of the area. Default value is 2.
#'@param shade A specification for the color of the shaded area. Default is "Red".
#'
#'@return A plot and curve of the specified normal distribution. And the area of the given bound under the curve is shaded in the color specified.
#'
#'@author Zhicong Chu
#'@export
#'
#'@examples 
#'my.normal(l=-10,u=11,shade="Red")  
#'my.normal(l=-10,u=5,shade="Purple")



my.normal=function(mean=10,sd=5,l=-2,u=2,shade="Red")
{
  xlow=mean-3*sd
  xup=mean+3*sd
  
  ifelse(l<xlow,xlow<-l-sd,xlow<-xlow) # if l is lower than xlow then make xlow 1 sd less than l
  ifelse(u>xup,xup<-u+sd,xup<-xup)
  # make a normal curve (must be a function of x)
  curve(dnorm(x,mean=mean,sd=sd),xlim=c(xlow,xup), ylab="Density")
  area<-pnorm(u,mean,sd)-pnorm(l,mean,sd)
  poly_x<-seq(l,u,length=1000)
  poly_y<-dnorm(poly_x,mean,sd)
  polygon(c(l,poly_x,u),c(0,poly_y,0),col=shade)
  area=round(area,4)
  text((l+u)/2,0.5*max(dnorm(l:u,mean,sd)),paste("Area=",area))
  #title(paste("Area between", l,"and", u, "is", area,))
}