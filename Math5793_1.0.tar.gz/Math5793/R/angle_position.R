#' Angle position 
#' 
#' This function takes two vectors a and b and calculate the relative angle position of a to the vector b.
#' 
#' @param a A numeric vector whose relative angle position is to be calculated.
#' @param b A numeric vector set as the reference. Default is c(1,0).
#' @return The relative angle position in radian.
#' @author Zhicong Chu
#' @details The range of the relative angle position is [0,2*pi]. It is the angle required to rotate clockwise for refrenece vector b to reach vector a.
#' @export
#' @examples 
#' angle_pos(c(0,1))
#' angle_pos(c(2,2),c(-1,0))       


angle_pos<-function(a,b=c(1,0)){ #function to idenctify the angle position
  output<-acos(a%*%b/(sqrt(sum(a^2))*sqrt(sum(b^2))))
  if (a[2]<0){
    output<--output
  }
  return(output)
}