#' multivariate normal distribution density.
#' 
#' This function provides the density function for the multivariate normal distribution.
#' @param x A numeric vector of quantiles.
#' @param sigma A numeric matrix of covariance.
#' @param mu A numeric vector of mean. 
#' @return The density value.
#' 
#' @author Zhicong Chu
#' @export
#' @examples 
#' sigma1<-matrix(c(10,-5,-5,20),ncol=2)
#' norm.den_p(matrix(c(-2,-2),ncol=2),sigma=sigma1,mu=c(0,0))
#' 


norm.den_p=function(x,sigma,mu) {
  p=dim(x)[2]
  a=1/((2*pi)^(p/2)*(det(sigma))^(1/2))
  b=-(x-mu)%*%solve(sigma)%*%matrix((x-mu),nrow=p)/2
  density=a*exp(1)^b
  return(density)
}