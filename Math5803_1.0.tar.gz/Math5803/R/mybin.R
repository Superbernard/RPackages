#' BRUGs Bionomial model
#' 
#' This function runs a Bionomial model via BRUGs with specified data  
#'  
#'  
#'@param n Number of iterations in each chain
#'@param n.chain Number of chains
#'@param a The first hyper-parameter of beta prior.
#'@param b The second hyper-parameter of beta prior.
#'
#'@return  \describe{A list that contains evidence and summary statistcs.
#'   \item{evidence}{A list that contains evidence value from MCMC simulation and 
#'   evidence from analytical solution as well.}
#'   \item{stats}{The summary statistcs.}
#' 
#' }
#'
#'@details 
#'The data is predefined (the eye color dataset). And a plot (3 subplots) will also be generated 
#'to display the 95 pctg BCI, 95 pctg HDI and the trace of the first 500 iterations on the 
#'same plot.
#'
#'
#'@author Zhicong Chu
#'@export  
#'@import BRugs
#'@examples
#'mybin(n=2000,n.chains=2,a=2,b=1)





mybin<-function(n,n.chains,a,b){
  # Defining the model
  modelstring=paste("
                    model{                             #OpenBUGS model wrote in sting\n
                    theta~dbeta(a,b)                   #hyperparameters a and b\n
                    a<-",a,"\n",
                    " b<-",b,"\n",
                    " x~dbin(theta,N_data)              #Integrate data into model\n
                    x<-3\n
                    N_data<-500\n
                    \n}\n"
                    
  )
  
  # Write the model to a file
  writeLines(modelstring,con="model.txt")
  
  #Check model
  modelCheck("model.txt")
  
  modelCompile( n.chains )
  
  writeLines("list(theta=0.5)",con="inits.txt")  #write a file containing the inits
  modelInits(rep("inits.txt", n.chains))  # read init data file
  modelUpdate(1000)                    # burn in
  samplesSet(c("theta"))     # theta should be monitored
  modelUpdate( n )                    # n more iterations ....
  
  
  ## Getting data in then we can play
  post=samplesSample("theta")       # Collect the MCMC posterior sample
  length(post)
  stat.hist=hist(post,plot=FALSE)
  br=stat.hist$breaks
  d=stat.hist$density
  h<-hist(post,plot=FALSE,breaks=50,freq=F)
  
  po_mu<-mean(post)
  
  
  graphics.off()
  windows()
  layout(matrix(c(1,1,1,1,1,0,2,2,2,2,2,0,0,0,3,3,3,3,3,0,0,0),
                2, 11, byrow = TRUE)) #specify the relative location of the plots
  
  
  nInc=500
  the<-seq(0,1,length=500)
  
  prior<-dbeta(the,a,b)
  
  lik<-dbinom(3,size=nInc,the)
  
  hist(prior,col="red",xlab=expression(theta),freq=F, breaks=50,
       ylab="Dencity",xlim=c(0,0.3),main="Prior")
  
  
  hist(lik,col="black",xlab=expression(theta), freq=F, breaks=50,
       ylab="Dencity",xlim=c(0,0.3),main="Likilihood")
  
  BCI<-quantile(post,prob=c(0.05,0.95))
  cuts1 = cut(h$breaks, c(0,BCI[1], BCI[2],1))
  plot(h, col=c(rgb(1,1,1,alpha=0.25),rgb(0,0,1,alpha=0.5),
                rgb(1,1,1,alpha=0.25))[cuts1],
       freq=FALSE,ylim=c(0,max(d)*1.1), 
       main="Posterior samples\n Zhicong",
       xlab=expression(theta))
  
  abline(v=po_mu,lwd=2,col="red")
  text(po_mu,max(d)*1.1,labels="point estimator (mean)",cex=1.5)
  
  
  
  HDI<-emp.hpd(post,conf=0.90)
  cuts2 = cut(h$breaks, c(0,HDI[1], HDI[2],1))
  plot(h, col=c(rgb(1,1,1,alpha=0.25),rgb(1,0,0,alpha=0.5),
                rgb(1,1,1,alpha=0.25))[cuts2],
       freq=FALSE,ylim=c(0,max(d)*1.1), 
       add=T)
  
  
  legend(0.02,max(d)*1.1,fill=c(rgb(0,0,1,alpha=0.5),rgb(1,0,0,alpha=0.5)),
         legend=c("90% BCI","90% HDI"),border="black",cex=1.2)
  
  
  
  
  # Calculating p(x) = 1/N*sum_theta|x [h(theta)/p(theta)f(x|theta)]
  N=length(post)
  # Use posterior to find a and b for a beta (h only needs to be close to the posterior)
  k=nInc+a+b   #what does this line mean?
  #k=sd(post)    # set k equal to standard deviation of posterior 
  w=median(post) # close to mode which is close to posterior mean
  ap=w*(k-2)+1   # shape1
  bp=(1-w)*(k-2)+1 #shape2
  
  invpx= 1/N*sum(dbeta(post,ap,bp)/(dbeta(post,a,b)*dbinom(3,size=nInc,prob=post)))
  # or
  px=1/mean(dbeta(post,ap,bp)/(dbeta(post,a,b)*dbinom(3,size=nInc,prob=post)))
  
  # Exact
  # Use any theta, I am using theta=0.5
  pxex=dbeta(0.5,a,b)*dbinom(3,size=nInc,prob=0.5)/dbeta(0.5,a+3,nInc-3+b)
  
  
  evidence=list(px=px,pxex=pxex)
  stats<-samplesStats("*")  #summary statitics 
  
  output=list(evidence=evidence,stats=stats)
  return(output)
  
  }