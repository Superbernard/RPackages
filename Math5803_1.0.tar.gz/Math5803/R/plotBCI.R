#' Plot BCI of MCMC sample
#' 
#' This function takes posterior sample and parameter of BCI range as well as 
#' the parameter name and plot out (1-alpha) BCI for the specified parameter .
#' 
#'@param postdist Posterior samples from MCMC.
#'@param alpha Parameter that determines BCI range to display on plot. (1-alpha) BCI
#'@param paraname The name of the parameter.
#'
#'@return Histgrams the parameter with (1-alpha) BCI marked.
#'
#'@author Zhicong Chu
#'@export
#'




plotBCI<-function(postdist,alpha,paraname){     #define a function to plot BCI       
  length(postdist)
  stat.hist=hist(postdist,plot=FALSE)
  br=stat.hist$breaks
  d=stat.hist$density
  h<-hist(postdist,plot=F,breaks=100)
  
  
  po_mu<-mean(postdist)
  
  BCI<-quantile(postdist,prob=c(alpha/2,(1-alpha/2)))
  BCI1<-BCI[1]
  BCI2<-BCI[2]
  xlow<-BCI1-0.1*(BCI2-BCI1)
  xhigh<-BCI2+0.1*(BCI2-BCI1)
  
  pctge<-(1-alpha)*100
  
  plot(h, col=rgb(0,0,1,alpha=0.25),
       freq=FALSE,ylim=c(0,max(d)*1.1),xlim=c(xlow,xhigh), 
       main=paste(pctge, "% BCI Posterior",paraname),
       xlab=paraname)
  
  abline(v=po_mu,lwd=2,col="red")
  text(po_mu,max(d),labels="point estimator (mean)")
  
  segments(BCI1,0,BCI2,0,col="black",lwd=5)
  points(x=c(BCI1,BCI2),y=c(0,0),pch=8,cex=2)
  
  return(po_mu)
}
