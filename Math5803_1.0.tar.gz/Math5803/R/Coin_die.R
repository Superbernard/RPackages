#' Coin-die simulation via MCMC
#' 
#' This function takes vector of dependent variable and the predictor matrix and calculate the estimate matrix beta.
#' 
#' 
#' @param n Number of iterations. (Number of trials. One flip of coin plus one toss of die is one trial.)
#' @param h The numeric vector containing the h1 and h2 values.
#' @param E2 The acceptance set.
#' @param init The initial state.
#' @param color The color setting in the bar plot.
#' @details The beta estimates are caculated via the least square method.
#' @return  \describe{A list of values that contains iteration table, 
#' posterior distribution from the simulation, posterior distribution from 
#' the analytical solution, posterior state of each iteration and latex table.
#'   \item{iter}{The iteration table containing the information of proposal state, acceptance probability,  acceptance set, die result and posterior state.}
#'   \item{sim}{The posterior distribution from the simulation. }
#'   \item{postexact}{The posterior distribution from the analytical solution.}
#'   \item{post}{The posterior state of each iteration.}
#'   \item{xtable}{The latex table.}
#' }
#' @export
#' @import xtable
#' @examples 
#'coindie(n=20,h=c(0.4,0.6),E2=c(3,4,5,6)) ->ans
#'ans
#' 
#' 
#' 
#' 

coindie<-function(n=100, h=c(1/4,3/4),E2=c(5,6),init=1,color="red"){
  #library(xtable)
  dieset<-c()
  dieset[1]<-"E1"
  die<-function(n=1){
    sample(1:6,size=n,replace=TRUE)
  }
  coin<-function(n=1){
    sample(1:2,size=n,replace=TRUE)
  }
  face<-c()
  alpha<-c() # holds acceptance probs
  alpha[1]<-1
  post<-c()# post sample
  prop<-c() # vec of proposed states 1s and 2s
  prop[1]=init # initial state
  post[1]=prop[1]
  dice<-c()
  dice[1]<-die()
  
  for(i in 2:n){ # starts at 2 because initial value given above
    prop[i]<-coin()
    alpha[i]=min(1,h[prop[i]]/h[post[i-1]])
    
    dice[i]<-die()
    ifelse(alpha[i]==1,dieset[i]<-"E1",dieset[i]<-"E2")
    # is x an element of set y
    if(alpha[i]==1 | (is.element(dice[i],E2) & alpha[i]!=1)){post[i]<-prop[i]}
    else{post[i]<-post[i-1]}
  }  
  res<-matrix(c(prop,round(alpha,2),dieset,dice,post ),nc=5,nr=n,byrow=FALSE,dimnames=list(1:n,c("proposal","alpha", "E","dice","post")))
  sim<-table(post)/n
  postexact<-h/sum(h)
  barplot(sim,main="posterior distribution",col=color,
          xlab="posterior state",ylab="probability")
  return(list(iter=res,sim=sim,postexact=postexact,post=post,xtable=xtable(res,dig=1)) )
}