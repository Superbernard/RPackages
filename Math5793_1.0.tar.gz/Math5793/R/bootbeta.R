#' Bootstrap for linear regression estimates beta
#' 
#' This function takes the vector of dependent variable and the predictor matrix and the time of iteration to calculate linear regression estimates beta.
#' 
#' @param Y The numeric vector that contains the values of dependent variable.
#' @param X The numeric vector/matrix contains the values of predictor/predictors.
#' @param iter The number of the iteration times.Default value is 10000.
#' @param epsilon The criteria set to check the determinant of product of the transpose of sampled X and the transpose of sampled Y. Default value is 1. 
#' 
#' 
#' @return  \describe{A list contains linear regression estimates matrix, outcome and predictor vector. Histograms of the ootstrap beta estimates will be also ploted. 
#'   \item{Summary}{A numeric scalor or vector that contains the rotated coordinate value or values on the new x axis.}
#'   \item{bh}{A matrix filled with bootstrap beta estimates. }
#'   \item{Y}{Outcome vector Y. }
#'   \item{X}{Predictor vector X. }
#'   \item{failure}{The vector records the index of the failed iterations. }
#'   \item{covariance}{The covariance matrix of the bootstrap estimated beta. }
#'   
#'
#'   
#' } 
#' 
#' 
#' @export
#' @importFrom rgl plot3d
#' @seealso \code{rgl}
#' @author Zhicong Chu
#' 
#' 
#' 




my.bootreg=function(Y,X,iter=10000,epsilon=1)  
  # iter = iterations  (given a default number of 10,000)
  # Y is a vector of response values
  #X is a data matrix with 1's in first column'
{
  n=dim(X)[1]
  # n is the number of rows
  nb=dim(X)[2]
  # nb is the number of columns and is equal to number of betas to be estimated
  beta.mat=matrix(NA,nr=nb,nc=iter)
  index.mat=matrix(NA,nr=n,nc=iter)
  failure=c()
  #X'X may become computationally singular - failures will say where
  for(i in 1:iter)
  {
    
    #index.mat[,i] =sample(1:n,replace=TRUE)
    ind=sample(1:n,replace=TRUE)
    #index.mat will be a matrix of random indices 
    #beta.mat[,i]=my.betah(Y[index.mat[,i]],X[index.mat[,i],])
    #ifelse(det(t(X[ind,])%*%X[ind,])<epsilon,beta.mat[,i]<-beta.mat[,i-1],beta.mat[,i]<-my.betah(Y[ind],X[ind,]))
    if(det(t(X[ind,])%*%X[ind,])<epsilon)
    {
      beta.mat[,i]<-beta.mat[,i-1]
      failure<-c(failure,i)
    }
    else
    {
      beta.mat[,i]<-my.betah(Y[ind],X[ind,])
    }
    #beta.mat[,i]=my.betah(Y[ind],X[ind,])
    #beta.mat is a matrix filled with bootstrap beta estimates
  }
  windows()
  layout(matrix(1:nb, nr=nb,nc=1,byrow=TRUE))
  for(i in 1:nb)
  {
    j=i-1
    # j will be the beta hat subscript
    hist(beta.mat[i,],nclass=30,freq=FALSE,
         ylab="Density"  , main="",
         xlab=substitute(hat(beta)[j]))
    # Annotation 
  }
  #windows()
  require(rgl)
  plot3d(beta.mat[1,],beta.mat[2,],beta.mat[3,])
  list(summary=apply(beta.mat,1,quantile,c(0.025,0.975)),bh=beta.mat, Y=Y,X=X, failure=failure,covariance=cov(cbind(t(beta.mat))))
}