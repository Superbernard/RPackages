#' Density plot from ggplot2
#' 
#' This function takes posterior samples from MCMC and the parameter names and 
#' return density plots  of all the parameters on the same layout.
#' 
#' @param postsamples Posterior samples from MCMC simulation.
#' @param paranames The vector that contains all the names of parameters monitered.
#' @return One graphic device that has all the density plots of parameters on the same layout.
#' @import ggplot2
#' @details All the density plot are ploted via histgrame in ggplot2 and has density
#' added on top.
#' @export
#' 
#' 
#' 

denplot<-function(postsamples,parnames){  #function to make histogram and density plots for posterior 
  #library(ggplot2)
  p<-list(22)
  dat<-as.data.frame(as.matrix(postsamples,chains=TRUE))
  dat<-dat[,-1]  #exclude the variable chain (first column)
  title<-parnames
  xl<-c(expression(kappa),expression(omega),rep(expression(theta),20))
  
  windows()
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(5, 5)))
  layout_r<-rep(1:5,each=5)  #row index for plots layout
  layout_c<-rep(1:5,5)       #column index for plots layout
  
  for (i in 1:22){
    # Histogram overlaid with kernel density curve
    p[[i]] <- ggplot() + aes(dat[,i], ..density..) + geom_histogram(color="Pink",fill="Red",bins=40)+
      geom_density(colour="black")+
      xlab(xl[i]) +
      ylab("Density") +
      ggtitle(title[i])
    
    
    print(p[[i]], vp = vplayout(layout_r[i], layout_c[i]))
    
  }
  
}
