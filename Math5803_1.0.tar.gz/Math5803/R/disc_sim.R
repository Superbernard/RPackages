#' Discrete simulations via MCMC from posterior
#' 
#' This function makes discrete simulations from a posterior with any number of h values
#' 
#' @param n Number of iterations. Default is 1000.
#' @param theta Discrete values of theta.
#' 
#' @return  \describe{A list contains iteration table, posterior distribution 
#' from MCMC simulation and posterior distribution from analytical solution.
#'   \item{iter}{Iteration matrix that contains values of prop,u,alpha and post of
#'    each iteration from MCMC simulation.}
#'   \item{sim}{Posterior distribution from MCMC simulation. }
#'   \item{post}{Posterior distribution from analytical solution. }
#'   
#' } 
#' 
#' @details A plot will be also generated that displays the posterior distribution 
#' from MCMC on different states.
#' @export
#' @author Zhicong Chu
#' @examples 
#' disease<- disc_sim( 10000, seq(0,1,length=20) )
#' 
#' 
#' 




disc_sim<-function(n=10000, theta){
  #put theta into input parameters.
  
  prior<-rep(1/length(theta), length(theta)) #prior follows uniform distribution
  
  lik<-dbinom(4,10,theta)  #likilihood 
  
  h<-numeric( length(theta) )  #blank vector that holds h
  
  h<-prior*lik  # h is definded as dot prodect of prior and likilihood 
  
  alpha<-c() # holds transition probs
  alpha[1]<-1
  u<-c() # holds uniform values
  u[1]<-1
  post<-c()# post sample
  prop<-c() # vec of proposed states 1s and 2s
  prop[1]=1 # initial state
  post[1]=prop[1]
  for(i in 2:n){ # starts at 2 because initial value given above
    # proposal state 
    prop[i]=sample(1:length(h),1,replace=TRUE)
    # calculate alpha
    # notice h[prop[i]] gives the actual value of h
    alpha[i]=min(1,h[prop[i]]/h[post[i-1]])
    # to calculate accepting proposal with prob alpha
    # select a random value from  a uniform (0,1)
    u[i]=runif(1)
    if(u[i]<=alpha[i]){post[i]<-prop[i]}
    else{post[i]=post[i-1]}
  }
  res<-matrix(c(prop,u,alpha,post ),nc=4,nr=n,byrow=FALSE)
  sim<-table(post)/n
  # windows only works with a pc
  # quartz with macs
  windows() 
  barplot(sim, col= "steelblue", xlab= "state", ylab="sample posterior",
          main= "Sample posterior from MCMC of Zhicong")
  postexact<-h/sum(h)
  # The returned output is a list 
  # Use obj$ to obtain whatever interests you
  output<-list(iter=res,sim=sim,post=postexact)
  return(output )
}