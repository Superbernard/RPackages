#' Q-Q plot
#' 
#' This function takes univariate x values and outputs the Q-Q plot of the sample.
#' 
#' @param x A numeric vector that contains the value of the sample.
#' @param main The specification of the name for the plot
#' @return A pop-out window with Q-Q plot in it.
#' @author Zhicong Chu
#' @export 
#' @examples  
#' x<-c(-1,-0.1,0.16,0.41,0.62,0.8,1.26,1.54,1.71,2.3)
#' windows()
#' myqq(x=x) 


myqq=function( x=rnorm(20,mean=10,sd=4), main="Normal Q-Q Plot")  {
  n=length(x) #n is the number of observations
  p=(1:n-0.5)/n
  q=qnorm( p,mean=0,sd=1)
  plot(q,sort(x),main=main,xlab="Theoretical Quantiles", ylab="Sample Quantiles")
}