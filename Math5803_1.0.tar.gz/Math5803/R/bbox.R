#' Bayes Box for discrete variables
#' 
#' This function take theta, prior and likelihood and calculate the posterior.
#' 
#'@param theta  A numeric vector that contains values of theta. 
#'@param prior  A numeric vector that contains the prior credibility on each value of theta.            .
#'@param lik  A numeric vector that contains the likelihood density of each value of theta.
#'@return A numeric vector that contains the posterior credibility on each value of theta.
#'@author Zhicong Chu
#'@details  The posterior prbability values are calculated analytically via Bayes formula.
#'A plot is also generated to display prior, likelihood and posterior on theta in one graph.
#'@export
#'@examples
#'theta=seq(0,1,length=20)
#'lik=dbinom(8,20,prob=seq(0,1,length=20))
#'temp1=dbeta(seq(0,1,length=20),2,1)
#'prior1= temp1/sum(temp1)
#'b1<-bbox(theta,prior1,lik)


bbox=function(theta,prior,lik){  # Three vectors
  
  post=prior*lik/sum(prior*lik) # post by discrete Bayes
  
  # tmp (temp) contains the matrix which will be the Bbox
  tmp=matrix(c(theta,prior,lik,prior*lik,post),nr=length(prior),nc=5,byrow=FALSE)
  colnames(tmp)=c("theta","prior","lik","prior*lik","post")
  lr=c(NA,sum(prior),NA ,sum(prior*lik),sum(post)) # a last row of NA's and sums
  tmp=rbind(tmp,lr) # bind it to the existing matrix
  
  graphics.off()
  windows()
  
  
  # plot prior posyt and lik
  plot(theta,post,type="b",lwd=2,pch=19,main="Bayes box of Zhicong",ylim=c(0,max(prior,lik,post)),col="Red")
  lines(theta,lik,type="b",lwd=2,col="Blue")
  lines(theta,prior,type="b",lwd=2,col="black")
  legend("topleft",legend=c("Prior","Posterior","Likelihood"),fill=c("black","red","blue"))
  
  # the last tmp will release the matrix to the command line.
  tmp
}
