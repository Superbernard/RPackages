#' Simulation: 20 coins from same mint. 
#' 
#' This function takes vales of hyper-parameter w and k to create dummy data and then
#' return Bayesian estimates from MCMC. 
#' 
#' @param w First hyper-parameter of theta.Default is 0.45.
#' @param k Second hyper-parameter of theta.Default is 20.
#' @return Summary information of Bayesian estimates from MCMC.
#' @details Density plots of all estimated parameters will also be generated on the same layout.
#' The function need to source zhicong.R and DBDA2E-utilities.R from JK to work. Have those two file
#' in the same dirctory before calling the function. 
#' 
#' @author Zhicong Chu
#' @export
#' @seealso \code{data_gen}   
#' \code{denplot}   
#' \code{vplayout}
#' @examples 
#' Baycase(k=100)
#' 



Baycase<-function(w = 0.45,k = 20){
  
  #library(rjags)
  #library(runjags)
  #library(ggplot2)
  #library(dplyr)
  #library(grid)
  dummydata<-data_gen(k=k)
  
  #------------------------------------------------------------------------------- 
  # Optional generic preliminaries:
  graphics.off() # This closes all of R's graphics windows.
  #------------------------------------------------------------------------------- 
  # Read The data file:
  myData = dummydata
  yName = "y" # column name for 0,1 values
  sName = "s" # column name for subject ID
  # Optional: Specify filename root and graphical format for saving output.
  # Otherwise specify as NULL or leave saveName and saveType arguments 
  # out of function calls.
  fileNameRoot = "zhicong" 
  graphFileType = "eps" 
  #------------------------------------------------------------------------------- 
  # # Read The data file:
  # myData = read.csv("StormTressoldiDiRisio2010data.csv")
  # yName = "Correct" # column name for 0,1 values
  # sName = "Study" # column name for "subject" ID
  # # Optional: Specify filename root and graphical format for saving output.
  # # Otherwise specify as NULL or leave saveName and saveType arguments 
  # # out of function calls.
  # fileNameRoot = "StormTressoldiDiRisio2010-" 
  # graphFileType = "eps" 
  #------------------------------------------------------------------------------- 
  # Load the relevant model into R's working memory:
  source("zhicong.R")
  #------------------------------------------------------------------------------- 
  # Generate the MCMC chain:
  mcmcCoda = genMCMC( data=myData , sName=sName , yName=yName , 
                      numSavedSteps=40000 , saveName=fileNameRoot , thinSteps=10 )
  #------------------------------------------------------------------------------- 
  # Display diagnostics of chain, for specified parameters:
  parameterNames = varnames(mcmcCoda) # get all parameter names for reference
  for ( parName in parameterNames[c(1:3,length(parameterNames))] ) { 
    diagMCMC( codaObject=mcmcCoda , parName=parName , 
              saveName=fileNameRoot , saveType=graphFileType )
  }
  #------------------------------------------------------------------------------- 
  # Get summary statistics of chain:
  summaryInfo = smryMCMC( mcmcCoda , compVal=w , 
                          diffIdVec=c(1,11,20),  # Therapeutic touch
                          # diffIdVec=c(38,60,2),  # ESP Tressoldi et al.
                          compValDiff=0.0 ,
                          saveName=fileNameRoot )
  # Display posterior information:
  plotMCMC( mcmcCoda , data=myData , sName=sName , yName=yName , 
            compVal=w , #rope=c(0.45,0.55) , # Therapeutic touch
            diffIdVec=c(1,11,20),              # Therapeutic touch
            # compVal=0.25 , #rope=c(0.22,0.28) , # ESP Tressoldi et al.
            # diffIdVec=c(38,60,2),               # ESP Tressoldi et al.
            compValDiff=0.0, #ropeDiff = c(-0.05,0.05) ,
            saveName=fileNameRoot , saveType=graphFileType )
  #------------------------------------------------------------------------------- 
  
  denplot(mcmcCoda,parameterNames)
  return(summaryInfo)
}
