#' BRUGs Bernouli model
#' 
#' This function runs a Bernouli model via BRUGs with specified data  
#'  
#'  
#'@param n Number of iterations in each chain
#'@param n.chain Number of chains
#'@param a The first hyper-parameter of beta prior.
#'@param b The second hyper-parameter of beta prior.
#'
#'@return  \describe{A list that contains BCI, HDI and summary statistcs.
#'   \item{BCI}{95 pctg BCI.}
#'   \item{HDI}{95 pctg HDI.}
#'   \item{stats}{The summary statistcs.}
#' 
#' }
#'
#'@import BRugs 
#'@details 
#'The data is predefined as 1,0,1,0,1,0,0,0,0,0. And a plot (3 subplots) will also be generated 
#'to display the 95 pctg BCI, 95 pctg HDI and the trace of the first 500 iterations on the 
#'same plot.
#'
#'
#'@author Zhicong Chu
#'@export  
#'
#'@examples
#'mybern(n=2000,n.chains=4,a=1,b=1)
#'
#'
#'





mybern <- function (n=10000, n.chains=3,a=1,b=1){
  #library(BRugs)
  #library(TeachingDemos)
  if (!requireNamespace("TeachingDemos", quietly = TRUE)) {
    stop("Pkg TeachingDemos needed for this function to work. Please install it.",
         call. = FALSE)
  }
  model_c(a,b)   #define and check the model
  
  # Make data
  datalist= list(
    X=c(1, 0, 1, 0, 1, 0, 0, 0, 0, 0),
    ntrials=10
  )
  
  modelData(bugsData(datalist))
  modelCompile( n.chains )
  
  writeLines("list(theta=0.5)",con="inits.txt")  #write a file containing the inits
  modelInits(rep("inits.txt", n.chains))  # read init data file
  modelUpdate(1000)                    # burn in
  samplesSet(c("theta"))     # theta should be monitored
  modelUpdate( n )                    # n more iterations ....
  
  ## Getting data in then we can play
  post=samplesSample("theta")       # Collect the MCMC posterior sample
  length(post)
  stat.hist=hist(post,plot=FALSE)
  br=stat.hist$breaks
  d=stat.hist$density
  h<-hist(post,plot=F,breaks=30)
  
  
  po_mu<-mean(post)
  
  graphics.off()
  windows()
  layout(matrix(c(1,1,1,1,1,0,2,2,2,2,2,0,0,0,3,3,3,3,3,0,0,0),
                2, 11, byrow = TRUE)) #specify the relative location of the plots
  
  
  BCI<-quantile(post,prob=c(0.05,0.95))
  cuts1 = cut(h$breaks, c(0,BCI[1], BCI[2],1))
  plot(h, col=c(rgb(1,1,1,alpha=0.25),rgb(0,0,1,alpha=0.25),
                rgb(1,1,1,alpha=0.25))[cuts1],
       freq=FALSE,ylim=c(0,max(d)*1.1), xlim=c(0,1),
       main="Posterior 90% BCI\n Zhicong",
       xlab=expression(theta))
  
  abline(v=po_mu,lwd=2,col="red")
  text(po_mu,3.1,labels="point estimator (mean)")
  
  
  
  HDI<-emp.hpd(post,conf=0.90)
  cuts2 = cut(h$breaks, c(0,HDI[1], HDI[2],1))
  plot(h, col=c(rgb(1,1,1,alpha=0.25),rgb(1,0,0,alpha=0.25),
                rgb(1,1,1,alpha=0.25))[cuts2],
       freq=FALSE,ylim=c(0,max(d)*1.1), xlim=c(0,1),
       main="Posterior 90% HDI\n Zhicong",
       xlab=expression(theta))
  
  abline(v=po_mu,lwd=2,col="red")
  text(po_mu,3.1,labels="point estimator (mean)")
  
  
  index<- (n*n.chains-500+1) : (n*n.chains)  #choose last 500 iterations of the last chain
  
  plot(index,post[index],type="b",main="trace plot of last 500 iteration",
       col="blue",xlab="number of iteration times", pch=19, ylab="posterior")
  
  
  stats<-samplesStats("*")  #summary statitics 
  
  
  output<-list(BCI=BCI,HDI=HDI,stats=stats)
  return(output)
  
}