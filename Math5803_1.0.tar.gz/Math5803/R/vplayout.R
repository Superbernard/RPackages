#' Layout for ggplot2
#' 
#' Function for arranging the plots layout.
#' 
#' @param x Number of rows of panels.
#' @param y Number of columns of panels.
#' @return The set-up of layout for ggplot2.
#' @author Zhicong Chu
#' @export 
#' 


vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y) 
#function for arranging the plots layout 