#' Multiple linear regression estimates
#' 
#' This function takes vector of dependent variable and the predictor matrix and calculate the estimate matrix beta.
#' 
#' 
#' @param Y The numeric vector that contains the values of dependent variable.
#' @param X The design matrix contains the values of predictor/predictors and intercept.
#' @details The beta estimates are caculated via the least square method.
#' @return The matrix that have beta estimates in rows.
#' @export
#' @seealso \code{my.design}
#' @examples 
#' data<-mtcars[,c(1,2,4)]
#' str(data)
#' summary(data)
#' X<-my.design(data[,-1])
#' my.betah(data[,1],X)
#' 
#' 
#' 
#' 

my.betah=function(Y,X)
{
  m<-length(Y)
  Y<-as.matrix(Y)
  X<-as.matrix(X)
  xxp<-t(X)%*%X
  xyp<-t(X)%*%Y
  invm<-solve(xxp)
  
  bh=invm%*%xyp
  return(bh)
}