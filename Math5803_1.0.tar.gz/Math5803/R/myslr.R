#' Likelihood function
#' 
#' This function takes inoput variable x and the other parameter of the density funtion and outputs the likelihood function.
#' 
#' @param n Number of data points.
#' @param seed Seed for the dummy data.
#' @param nit Number of iterations in each chain.
#' @param b0 Parameter of intercept in dummy data.
#' @param b1 Parameter of slope in dummy data.
#' @param std Standard deviation of error term in dummy data.
#' @param tau0 Prior value of tau of normal distribution for Beta0.
#' @param tau1 Prior value of tau of normal distribution for Beta1.
#' 
#' @return  \describe{A list of values that contains estimate information from both Bayesian
#' and classical models
#'   \item{stats}{The summary statistics from BRUGs}
#'   \item{classic}{The coefficients from classical model.}
#'   \item{class_y}{The predicted y values from classical model  .}
#' }
#'   
#' @author Zhicong Chu
#' @details A plot (3 subplots) will also be generated to display the histgrams of 
#' Bayesian estimates of Beta0, Beta1 and sigma on the same plot.
#' @export
#' @import BRugs
#' @examples 
#'myslr(seed=100,n=10,nit=10000,b0=12,b1=8,std=10,tau0=0.00001,tau1=0.00001)
#'
#'myslr(seed=100,n=30,nit=10000,b0=12,b1=8,std=10,tau0=0.00001,tau1=0.00001)



myslr<-function(n,seed,nit,b0,b1,std,tau0,tau1){
  
  graphics.off()
  options(scipen=999)  #disable scientific notation
  
  #specify data
  X=seq(1,n,by=1)
  set.seed(seed);Y=b0 +b1*X +rnorm(n,mean=0,sd=std)
  Y=round(Y,2)
  #Y[10]<-NA
  Y
  #dput(Y)
  
  
  #library(BRugs)
  # Defining the model
  modelstring=paste("
                    model{\n
                    for(i in 1:N){ # loading the lik\n
                    Y[i]~dnorm(mu[i],tau)# Y normally dist\n
                    mu[i]<-beta0+beta1*X[i] # Linear regression\n
                    }\n
                    beta0~dnorm(0,tau0) # prior on intercept\n
                    beta1~dnorm(0,tau1) # prior on slope\n
                    sigma~dunif(0,100) # 1/sigma^2  prior on tau\n
                    tau<-pow(sigma,-2)\n
                    # predict a new y value when X=10.5\n
                    y.new~dnorm(mu.new,tau)\n
                    mu.new<-beta0+beta1*10.5\n
                    proby<-step(y.new)\n","tau0<-",tau0,"\n",
                    "tau1<-",tau1,"\n\n}"
  )
  
  # Write the model to a file
  writeLines(modelstring,con="model.txt")
  dir()
  
  #Check model
  modelCheck("model.txt")
  
  # Make data
  datalist=
    list(Y=Y
         ,
         X=X,
         N=n
    )
  
  modelData(bugsData(datalist))
  modelCompile(numChains=3)
  
  
  writeLines("list(beta0=4,beta1=0,sigma=3,y.new=10)",con="inits.txt")  #write a file containing the inits
  modelInits(rep("inits.txt", 3))  # read init data file
  modelGenInits()      # Generate inits for anything left
  
  modelUpdate(1000)                    # burn in
  samplesSet(c("beta0","beta1","sigma","y.new"))     # all parameters should be monitored
  #samplesSet(c("beta0","beta1","sigma","y.new","Y[10]"))     # all parameters should be monitored
  modelUpdate(nit)                    # nit more iterations ....
  samplesStats("*")
  post_b0=samplesSample("beta0")
  post_b1=samplesSample("beta1")
  post_sig=samplesSample("sigma")
  
  windows()
  layout(matrix(c(1,1,1,1,1,0,2,2,2,2,2,0,0,0,3,3,3,3,3,0,0,0),
                2, 11, byrow = TRUE)) #specify the relative location of the plots
  
  hinfo=hist(post_b0,freq=FALSE,plot=F,breaks=30)
  hist(post_b0,freq=FALSE,col=rainbow(length(hinfo$breaks)),
       main=paste(expression(beta),0),xlab=expression(beta0))
  lines(density(post_b0))
  
  hinfo=hist(post_b1,freq=FALSE,plot=F,breaks=30)
  hist(post_b1,freq=FALSE,col=rainbow(length(hinfo$breaks)),
       main=paste(expression(beta),1),xlab=expression(beta1))
  lines(density(post_b1))
  
  hinfo=hist(post_sig,freq=FALSE,plot=F,breaks=30)
  hist(post_sig,freq=FALSE,col=rainbow(length(hinfo$breaks)),
       main="sigma",xlab=expression(sigma))
  lines(density(post_sig))
  
  ## Classical analysis
  y.lm=lm(Y~X)
  classic<-summary(y.lm)
  class_y<-predict(y.lm,data.frame(X=10.5))   #prediction from classic model
  
  
  stats<-samplesStats("*")  #summary statitics 
  output<-list(stats=stats,classic=classic$coefficients,class_y<-class_y)
  
  return(output)
  
  
  }