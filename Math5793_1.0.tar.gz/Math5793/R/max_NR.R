#' Maximum likelihood parameter, Newton-Raphson
#' 
#' This function uses Newton-Raphson method to find the value of parameter for maximum likelihood.
#' 
#' @param t0 An initial guess of the root. It is actually a parameter for the NR_root function.
#' @param pdfun The probability density function of the distribution of x. It is actually a parameter for the likeh function.
#' @param delta The "change in" term. Default value is 0.0001. It is actually a parameter for the fdash function.
#' @param epsilon The loop parameter that make sure it does not loop too much. Since the algorism only 
#' provide the approximate root, so the function gets close enough to zero, loop will stop.Default value is 1e-12.
#' It is actually a parameter for the NR_root function. 
#' 
#' @return The estimated value of parameter for maximal likelihood via Newton-Raphson method.
#' 
#' @details This function takes in the probability density function and works out the likelihood function for the distribution. 
#' Then it calculates an approximate estimate of the value of parameter of the distribution at the maximum likelihood via Newton-Raphson algorism.
#' @author Zhicong Chu
#' @seealso \code{likeh}  
#' @seealso \code{NR_root}
#' @seealso \code{fdash}
#' @seealso \code{findt0}
#' @export
#' 
#' @examples 
#' logpoiss=function(x,param) log(dpois(x,lambda=param)) #poisson distribution, log form
#' t0poiss<-findt0(logpoiss,c(3,4,3,5))
#' t0poiss
#' mymaxlik_NR(t0poiss,logpoiss,x=c(3,4,3,5),0.0001)
#' 
#' 
#' 

mymaxlik_NR=function(t0=1,pdfun,x,delta=0.0001,epsilon=1e-12){
  #Function using Newton-Raphson method to find appropiate parameter 
  #value for maximum likelihood
  
  ###specify likelihood function
  likelihood=function(param){     
    output=likeh(x,param,pdfun)
  }
  
  ###specify the derivative of likelihood function which is to be zeroed
  DR_likelihood=function(param){
    output=fdash(param,likelihood,delta)
  }
  
  ###NR method to find the root
  max_para=NR_root(DR_likelihood,1e-12,t0)$root
  
  
  return(max_para)
  
}
