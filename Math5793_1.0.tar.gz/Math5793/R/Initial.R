#' Initial guess for NR
#' 
#' This function takes the density function of the distribution and output an initial guess of the root for the Newton-Raphson algorism and mymaxlik_NR function.
#' 
#' @param pdfun The probability density function of the distribution of x.
#' @param x A numeric vector that contains the values of the input variable of the sample.   
#' @return an initial guess of the root for the mymaxlik_NR function.
#' @details The function will generate a pop-out window with the curve of the likelihood function, and the user has to manually pick the appropiate value by clicking the curve at a point near the horizontal axis which is x=0. Then the x value of that point will be returned as the initial guess.
#' @seealso \code{locator}
#' @author Zhicong Chu
#' @export
#' 
#' @examples 
#' logpoiss=function(x,param) log(dpois(x,lambda=param)) #poisson distribution, log form
#' t0poiss<-findt0(logpoiss,c(3,4,3,5))
#' t0poiss





findt0=function(pdfun,x){
  #function to find an appropriate initial guess for NR Algorithm
  likelihood=function(param){
    output=likeh(x,param,pdfun)
    return(output)
  }
  
  fdash_lh=function(param){
    output=fdash(param,likelihood)
    return(output)
  }
  
  windows()
  curve(fdash_lh,xlab="parameter",ylab="f",main="f(x)")
  abline(h=0,col="Red",lwd=2)
  t0=locator(1)$x
  return(t0)
}