#' BRUGs hierarchical model. (A Single Coin From a Mint.)
#' 
#' This function runs a hierarchical model via BRUGs simulating the case of 
#' a single coin from a mint.  
#'  
#'@param y The vector containing values of response variable in dataset. 
#'@param K Kappa, the value of upper hyper-parameter of a and b of beta distribution. 
#'@param alpha The parameter setting for (1-alpha) BCI.
#'@param nit Number of iterations in each chain. Default is 10000.
#'
#'@return  \describe{A list that contains summary statistcs, summery table of iterations and BCI.
#'   \item{stats}{The summary statistcs.}
#'   \item{Rsum}{The summary table of posterior of each iteration.}
#'   \item{BCI}{The (1-alpha) BCI.}
#' }
#'@import BRugs 
#'@details 
#'A plot will also be generated to display the histgram of posterior from MCMC with
#'95 percentage BCI marked on the plot.
#'
#'
#'
#'@author Zhicong Chu
#'@export  
#'
#'@examples
#'myhyier1(y=y,K=5,alpha=10,nit=10000)

myhyier1 <- function (y=y,K=5,alpha=0.1, nit=10000){
  #library(BRugs)
  #library(TeachingDemos)
  if (!requireNamespace("TeachingDemos", quietly = TRUE)) {
    stop("Pkg TeachingDemos needed for this function to work. Please install it.",
         call. = FALSE)
  }
  # Defining the model
  modelstring="       
  model{
  for (i in 1:n){
  y[i]~dbern( theta )
  }
  theta~dbeta( a, b )
  a<-K-2+1
  b<-(1-w)*(K-2)+1
  w~dbeta(2,2)
  }"
  
  # Write the model to a file
  writeLines(modelstring,con="model.txt")
  dir()
  
  #Check model
  modelCheck("model.txt")
  
  # Make data
  datalist=
    list(y=y,
         n=length(y),
         K=K
    )
  
  
  modelData(bugsData(datalist))
  modelCompile( 3 )
  
  
  writeLines("list(theta=0.5,w=0.5)",con="inits.txt")  #write a file containing the inits
  modelInits(rep("inits.txt", 3))  # read init data file
  modelGenInits()  #Generate inits for anything left
  
  modelUpdate(1000)                    # burn in
  samplesSet(c("theta","w"))     # theta should be monitored
  modelUpdate( nit )                    # n more iterations ....
  
  ## Getting data in then we can play
  post_theta=samplesSample("theta")       # Collect the MCMC posterior sample
  post_w=samplesSample("w")
  
  post=post_theta           #We only care about theta here
  length(post)
  stat.hist=hist(post,plot=FALSE)
  br=stat.hist$breaks
  d=stat.hist$density
  h<-hist(post,plot=F,breaks=30)
  
  
  po_mu<-mean(post)
  
  graphics.off()
  windows()
  
  BCI<-quantile(post,prob=c(alpha/2*0.01,(1-alpha/2*0.01)))
  BCI1<-BCI[1]
  BCI2<-BCI[2]
  
  pctge<-(1-alpha*0.01)*100
  
  plot(h, col=rgb(0,0,1,alpha=0.25),
       freq=FALSE,ylim=c(0,max(d)*1.1), xlim=c(0,1),
       main=paste(pctge, "% BCI Posterior \n Zhicong"),
       xlab=expression(theta))
  
  abline(v=po_mu,lwd=2,col="red")
  text(po_mu,max(d),labels="point estimator (mean)")
  
  segments(BCI1,0,BCI2,0,col="black",lwd=5)
  points(x=c(BCI1,BCI2),y=c(0,0),pch=8,cex=2,add=T)
  
  stats<-samplesStats("*")  #summary statitics 
  Rsum<-summary(post)
  
  output<-list(stats=stats,Rsum=Rsum,BCI=BCI)
  return(output)
  
}

