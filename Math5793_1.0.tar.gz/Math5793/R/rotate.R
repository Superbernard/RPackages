#' Rotate the coordinates
#' 
#' Takes in x and y coordinate values and an angle and rotate coordinates. 
#' 
#'@param x1 A numeric scalor or vector that represents the coordinate 
#'   value or values on the horizontal axis. 
#'@param x2 A numeric scalor or vector that represents the coordinate 
#'   value or values on the vertival axis. 
#'@param theta A numeric value represents the angle to rotate in radian.
#'
#'@return  \describe{A list that contains the new coordinate values after rotation. 
#'   \item{x1t}{A numeric scalor or vector that contains the rotated coordinate value or values on the new x axis.}
#'   \item{x2t}{A numeric vector that contains values of the zerofun after each iteration. }
#'
#'   
#' } 
#' 
#'       
#'
#'   
#'@author Zhicong Chu
#'   
#'@details This function conduct a rotation on the coordinates based on an angle 
#'   value and two scalers or vectors x and y that containing coordinate values of 
#'   horizontal and vertical axes. The new coordinate values on the rotated axes are
#'   calculated. 
#'    
#'@export
#'  


my.tilde=function(x1,x2,theta){ # x1,x2 vectors, theta scalar
  x1t=x1*cos(theta)+x2*sin(theta)
  x2t=-x1*sin(theta)+x2*cos(theta)
  list(x1t=x1t,x2t=x2t)
}