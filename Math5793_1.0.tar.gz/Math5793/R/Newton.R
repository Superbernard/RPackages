#' Newton-Raphson
#' 
#' This function solves the equation zerofun=0 via Newton-Raphson algorism.
#' 
#' @param zerofun   The function to be zeored to form the equation.
#' @param epsilon   The loop parameter that make sure it does not loop too much. Since the algorism only 
#' provide the approximate root, so the function gets close enough to zero, loop will stop.Default value is 1e-12.
#' @param t An initial guess of the root.
#' 
#' @return  \describe{A list of values contain t which is the initial guess of the root, the y value after each iteraton and d which is the final y value after all the iterations as well as the approximate root.
#'   \item{t}{The initial guess}
#'   \item{y}{A numeric vector that contains values of the zerofun after each iteration. }
#'   \item{d}{The final y value after all the iterations.}
#'   \item{root}{The approximate root}
#'   
#' } 
#' 
#' @author Zhicong Chu
#' 
#' @details Although the equation can have multiple roots, the function can only estimate one of the roots. Which root to return depends on the initial guess provided. Plots will also generated in a pop-out window to demonstrate the iterations.
#' 
#'
#' 
#' @export 
#' @examples 
#' myfun=function(x) 4*x^2-27*x+13
#' windows()
#' curve(myfun,xlab="parameter",ylab="f",main="f(x)",xlim=c(-10,10))
#' abline(h=0,col="Red",lwd=2)
#' t0=locator(1)$x
#' NR_root(myfun,t0=t0)
#'      


NR_root=function(zerofun,epsilon=1e-12,t0){
  #Function that uses Newton-Raphson method to solve the equation zeorfun(t)=0
  #and returnt the root of the equation 
  d=1000
  i=0
  t=c() # empty vectors
  y=c()
  t[1]=t0 # assign initial guess
  y[1]=zerofun(t[1]) # initial y value
  while(d > epsilon & i<100){ # ensures that it doesnt loop too much
    i=i+1 
    t[i+1]=t[i]-zerofun(t[i])/fdash(t[i],orifun=zerofun) # NR step
    y[i+1]=zerofun(t[i+1]) # update y value
    d=abs(y[i+1]) # update d   
  }
  
  windows()
  #Cut the graphical area into two
  layout(matrix(1:2,nr=2,nc=1,byrow=TRUE),heights=c(3,4))
  curve(zerofun,xlim=c(abs(t0)-5,5+abs(t0)),ylim=c(-15,15),xlab="parameter",ylab="f",main="f(t)")  #Here zerofun(t) is denoted as f(t) corresponding to fdash(t) 
  abline(h=0,col="Red",lwd=2)
  
  # plot f with no x axis  on a reduced x range
  curve(zerofun,xaxt="n",xlim=c(abs(t0)-5,5+abs(t0)), ylim=c(-15,15),xlab="parameter",ylab="f",main=  "Newton-Raphson Algorithm")
  points(t,y,col="Red",pch=19,cex=0.5)
  # Now plot the x axis
  axis(1,t,round(t,2),las=2)
  abline(h=0,col="Red")
  
  segments(t[1:(i-1)],y[1:(i-1)],t[2:i],rep(0,i-1),col="Blue",lwd=0.5)
  segments(t[2:i],rep(0,i-1),t[2:i],y[2:i],lwd=0.5,col="Green")
  # paste the root onto the last graph
  arrows(x0=t[i+1],y0=y[1],x1=t[i+1],y1=y[i+1])
  text(t[i+1],y[1],t[i+1])
  
  list(t=t,y=y,d=d,root=t[i+1])
}


