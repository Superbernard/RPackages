#' Design matrix with interaction
#' 
#' This function takes the original matix X without intercept or interaction, and output a design matrix with intercept and all possible interactions.
#'  
#' @param X The original matrix of predictors in columns without intercept.
#' @return The design matrix with intercept and all possible interactions.
#' @details This function can only handle Xs with 2 or 3 variables which means it will not work if X has more than 3 columns.
#' @author Zhicong Chu
#' @export  
#' @examples 
#' 
#' data<-mtcars[,c(1,2,4)]
#' str(data)
#' summary(data)
#' X<-my.design(data[,-1])
#' head(X)


my.design<-function(X){
  m=dim(X)[1]
  n=dim(X)[2]
  Intercept= rep(1,m)
  if (n==2){
    Int<-X[,1]*X[,2]
    X<-cbind(Intercept,X,Int)
  }
  else if (n==3){
    Int1<-X[,1]*X[,2]
    Int2<-X[,2]*X[,3]
    Int3<-X[,1]*X[,3]
    Int4<-X[,1]*X[,2]*X[,3]
    X<-cbind(Intercept,X,Int1,Int2,Int3,Int4)
  }
  return(X)
}